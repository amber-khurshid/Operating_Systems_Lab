
#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
int main() {
    pid_t pid;
    pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        exit(1);
    }
    else if (pid == 0) {
        printf("Child process\n");
        printf("Child process id: %d\n", getpid());
        printf("Parent process id: %d\n", getppid());
        sleep(120);
    }
    else {
        printf("Parent process\n");
        printf("Parent process id: %d\n", getpid());
        printf("Child process id: %d\n", pid);
        printf("Killing the child process\n");
       kill(pid, 9);
      // wait for 120 seconds
        sleep(120);
    }
    return 0;
}

