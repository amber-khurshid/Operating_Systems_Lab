
#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main() {
    pid_t pid;
    pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        exit(1);
    }
    else if (pid == 0) {
        printf("Child process\n");
        printf("Child process id: %d\n", getpid());
        printf("Parent process id: %d\n", getppid());
       printf("Killing the parent process\n");
        kill(getppid(), 9);
        sleep(120);

    }
    else {
        sleep(1);
        printf("Parent process\n");
        printf("Parent process id: %d\n", getpid());
        printf("Child process id: %d\n", pid);
    
    }
    return 0;
}