#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
int main() {


printf("Tazmeen Afroz\n");
printf("22P-9252\n");
printf("BAI-5A\n");
int sum = 0;
int a = 6, b= 5;
sum = a + b;
printf("sum = %d\n", sum);
printf("Killing the current process\n");
// sleep(2);
kill(getpid(), 9);
printf("doesnot print\n");
}
