#include <stdio.h>
#include <stdlib.h>
#include<sys/types.h>
#include<unistd.h>



int main(){
  pid_t pid;
  
   
	printf("\nThis is C Programming in Ubuntu\n\n");
        printf("\nHere in this program we will run linux commands\n\n");
        system("ls -l");

  
        pid = fork();

        if(pid < 0)
        {
            printf("Fork Failed\n");
        }

        else if(pid == 0)
        {
            printf("This is Child process\n");
            printf("Child's PID: %d\n", getpid());
            printf("Parent's PID: %d\n", getppid());
        }

        else
        {
            printf("This is Parent process\n");
            printf("Parent's PID: %d\n", getpid());
            printf("Child's PID: %d\n", pid);
            printf("Parent ID of Parent: %d\n", getppid());
        }
	return 0;

}
