#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int fork_count = 0; 

int main(void)
{
    int i;
    printf("Process PID %6d \t PPID %6d \n", getpid(), getppid());
    for (i = 0; i < 100; ++i)
    {
        if (fork() == 0)
        {
            fork_count++;
            printf("Process PID %6d \t PPID %6d \n", getpid(), getppid());
            if (fork_count == 3)
               break;
            exit(0);
            
        }
        else
        {
            fork_count++;
            if (fork_count == 3)
            {
                break;
            }
        }
    }
    printf("Total fork() calls: %d\n", fork_count);
    return 0;

}